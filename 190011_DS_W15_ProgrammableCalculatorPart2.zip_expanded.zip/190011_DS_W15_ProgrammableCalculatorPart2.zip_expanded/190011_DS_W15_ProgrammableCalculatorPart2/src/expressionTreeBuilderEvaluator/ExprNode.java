package expressionTreeBuilderEvaluator;

import lexer.Token;
import lexer.Token.Kind;
/**
 * <p> Title: Variable Class. </p>
 *  Date: 5 May 2021
 * <p> Description: A component of the data structure for the application that handles data of different factors of an operand such as 
 * 					the value , error term and unit of a variable  </p>
 * 
 * <p> Copyright: Lynn Robert Carter, Ruchi © 2021 </p>
 * 
 ** @author Lynn Robert Carter, Ruchi
 *
 * @version 4.0.7	2021-05-05 The JavaFX-based GUI for the implementation of a Programmable calculator with variables
 */

public class ExprNode {
	/**********************************************************************************************
	Class Attributes
	**********************************************************************************************/
	private ExprNode left;
	private ExprNode right;
	private Token op;
	private boolean isBinary;
	/**********************************************************************************************
	Constructors
	**********************************************************************************************/
	/***********
	 * This is defining constructor.  This is the one we expect people to use.
	 * 
	 * @param o    operand
	 * @param b    operand type is whether binary or not
	 * @param l    left node of the parent node
	 * @param r    right node of the parent node
	 */
	public ExprNode(Token o, boolean b, ExprNode l, ExprNode r) {
		op = o;
		isBinary = b;
		left = l;
		right = r;
	}
	/*************************** These are the getters for the class*******************************/
	/****
	 * 
	 * @return operand is returned
	 */
	public Token getOp() {
		return op;
	}

	/************
	 * 
	 * @return left sub tree value is returned
	 */
	public ExprNode getLeft() {
		return left;
	}

	/***************
	 * 
	 * @return right sub tree value is returned
	 */
	public ExprNode getRight() {
		return right;
	}
	
	/***********
	 * 
	 * @param indent   this is for advanced purposes
	 * @return incident  this is for advanced purposes
	 */
	private String toString(String indent) {
		if (op.getTokenKind() == Kind.SYMBOL)
			if (isBinary)
				return indent + "Op: " + op + "\n" + 
				left.toString(indent + "   ") + "\n" + right.toString(indent + "   ");
			else
				return indent + "Op: " + op + "\n" + right.toString(indent + "   ");
		else
			return indent + "Leaf: " + op;
	}
	
	public String toString() {
		return this.toString("");
	}
}
