package calculator;

/**
 * <p> Title: Variable Class. </p>
 *  Date: 5 May 2021
 * <p> Description: A component of the data structure for the application that handles data of different factors of an operand such as 
 * 					the value , error term and unit of a variable  </p>
 * 
 * <p> Copyright: Lynn Robert Carter, Ruchi © 2021 </p>
 * 
 ** @author Lynn Robert Carter, Ruchi
 *
 * @version 4.0.7	2021-05-05 The JavaFX-based GUI for the implementation of a Programmable calculator with variables
 */
public class Variable {
	/**********************************************************************************************
	Class Attributes
	**********************************************************************************************/	
	String variable="";                
	String value="";			 
	String errorterm="";			  
	String unit="";			 
	
	/**********************************************************************************************
	Constructors
	**********************************************************************************************/
	/**********
	 * This is the default constructor.  
	 */
	public Variable() {
		variable = " ";
		value= " ";
		errorterm= " ";
		unit=" ";
	}
	/**********
	 * This is defining constructor.  This is the one we expect people to use.
	 * 
	 * @param vr  variable
	 * @param va  value of the variable
	 * @param er  error term of the variable
	 * @param u   unit of the variable
	 * 
	 */
	public Variable(String vr, String va, String er, String u) {
		variable = vr;
		value= va;
		errorterm= er;
		unit=u;
	}
	/*************************** These are the getters for the class*******************************/
	
	/***************
	 * This is a getter function which gets the Variable 
	 * 
	 * @return variable is returned 
	 */
	public String getVariable() {
		return variable;
	}
	
	/***************
	 * This is a getter function which gets the Value of the Variable
	 * 
	 * @return value is returned 
	 */
	public String getValue() {
		return value;
	}
	
	/***************
	 * This is a getter function which gets the Error Term of the Variable
	 * 
	 * @return error term is returned 
	 */
	public String getErrorterm() {
		return errorterm;
	}
	
	/***************
	 * This is a getter function which gets the Unit  of the Variable
	 * 
	 * @return unit is returned 
	 */
	public String getUnit() {
		return unit;
	}
	
	/***************
	 * This is a setter function which sets the Variable
	 * 
	 * @param vr  Variable 
	 */
	public void setVariable(String vr) {
		variable=vr;
	}
	
	/***************
	 * This is a setter function which sets the Value of the Variable
	 * 
	 * @param vl  Value 
	 */
	public void setValue(String vl) {
		value=vl;
	}
	
	/***************
	 * This is a setter function which sets the Error Term of the Variable
	 * 
	 * @param er  Error Term 
	 */
	public void setErrorterm(String er) {
		errorterm=er;
	}
	
	/***************
	 * This is a setter function which sets the Unit of the Variable
	 * 
	 * @param un  Unit 
	 */
	public void setUnit(String un) {
		 unit=un;
	}
	
	/***********
	 * This function adds a new entry which is actually used to add a new dynamic entry to the list 
	 * 
	 * @param vr  variable 
	 * @param va  value
	 * @param er  error term
	 * @param u   unit
	 */
	public void addEntry(String vr, String va, String er, String u) {
		variable = vr;
		value= va;
		errorterm= er;
		unit=u;
	}

}
